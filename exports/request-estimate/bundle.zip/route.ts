export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const url = process.env.CALENDAR_ICS_URL;
  if (!url) {
    return new Response("Missing env var: CALENDAR_ICS_URL", { status: 500 });
  }

  try {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) {
      return new Response(`Failed to fetch ICS (HTTP ${res.status})`, {
        status: 502,
      });
    }

    const text = await res.text();

    return new Response(text, {
      headers: {
        "content-type": "text/calendar; charset=utf-8",
        "cache-control": "no-store",
      },
    });
  } catch {
    return new Response("Failed to fetch ICS", { status: 502 });
  }
}
