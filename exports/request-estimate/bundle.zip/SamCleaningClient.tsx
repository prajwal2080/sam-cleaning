"use client";

import { useEffect } from "react";

type FlatpickrInstance = {
  set: (key: string, value: unknown) => void;
  redraw: () => void;
  destroy: () => void;
};

declare global {
  interface Window {
    flatpickr?: (el: Element, opts: Record<string, unknown>) => FlatpickrInstance;
    ICAL?: any;
  }
}

export default function SamCleaningClient() {
  useEffect(() => {
    const slides = Array.from(document.querySelectorAll<HTMLElement>(".slide"));
    const nextBtn = document.querySelector<HTMLButtonElement>(
      ".slider-btn.next"
    );
    const prevBtn = document.querySelector<HTMLButtonElement>(
      ".slider-btn.prev"
    );
    const menuToggle = document.querySelector<HTMLButtonElement>(".menu-toggle");
    const mainNav = document.querySelector<HTMLElement>(".main-nav");
    const revealSections = Array.from(
      document.querySelectorAll<HTMLElement>(
        ".about-showcase, .services-section, .estimate-cta, .request-estimate, .pricing-section, .specialists-section, .testimonials-section, .site-footer"
      )
    );

    let activeIndex = 0;
    let autoTimer: number | undefined;
    let sectionObserver: IntersectionObserver | null = null;
    const cleanupFns: Array<() => void> = [];

    function showSlide(index: number) {
      if (slides.length === 0) return;
      activeIndex = (index + slides.length) % slides.length;
      slides.forEach((slide, i) => {
        slide.classList.toggle("active", i === activeIndex);
      });
    }

    function startAutoSlide() {
      if (autoTimer) window.clearInterval(autoTimer);
      autoTimer = window.setInterval(() => {
        showSlide(activeIndex + 1);
      }, 6000);
    }

    function startCounterAnimation(section: HTMLElement | null) {
      if (!section || section.dataset.counted === "true") {
        return;
      }

      const counters = Array.from(
        section.querySelectorAll<HTMLElement>(".counter-value")
      );
      if (counters.length === 0) {
        return;
      }

      section.dataset.counted = "true";
      const reduceMotion = window.matchMedia(
        "(prefers-reduced-motion: reduce)"
      ).matches;

      counters.forEach((counter) => {
        const target = Number.parseInt(counter.dataset.target || "0", 10);
        const duration = Number.parseInt(counter.dataset.duration || "1800", 10);

        if (!Number.isFinite(target) || target < 0) {
          return;
        }

        if (reduceMotion) {
          counter.textContent = String(target);
          return;
        }

        const startTime = performance.now();
        counter.textContent = "0";

        function updateCounter(now: number) {
          const progress = Math.min((now - startTime) / duration, 1);
          const eased = 1 - Math.pow(1 - progress, 3);
          const current = Math.floor(target * eased);
          counter.textContent = String(current);

          if (progress < 1) {
            requestAnimationFrame(updateCounter);
          } else {
            counter.textContent = String(target);
          }
        }

        requestAnimationFrame(updateCounter);
      });
    }

    // Slider
    if (nextBtn && prevBtn && slides.length > 1) {
      const onNext = () => {
        showSlide(activeIndex + 1);
        startAutoSlide();
      };
      const onPrev = () => {
        showSlide(activeIndex - 1);
        startAutoSlide();
      };

      nextBtn.addEventListener("click", onNext);
      prevBtn.addEventListener("click", onPrev);
      cleanupFns.push(() => {
        nextBtn.removeEventListener("click", onNext);
        prevBtn.removeEventListener("click", onPrev);
      });

      startAutoSlide();
      cleanupFns.push(() => {
        if (autoTimer) window.clearInterval(autoTimer);
      });
    }

    // Mobile menu
    if (menuToggle && mainNav) {
      const onToggle = () => {
        const expanded = menuToggle.getAttribute("aria-expanded") === "true";
        menuToggle.setAttribute("aria-expanded", String(!expanded));
        mainNav.classList.toggle("open");
      };

      menuToggle.addEventListener("click", onToggle);
      cleanupFns.push(() => menuToggle.removeEventListener("click", onToggle));

      const links = Array.from(mainNav.querySelectorAll<HTMLAnchorElement>("a"));
      const onLinkClick = () => {
        menuToggle.setAttribute("aria-expanded", "false");
        mainNav.classList.remove("open");
      };
      links.forEach((link) => link.addEventListener("click", onLinkClick));
      cleanupFns.push(() => links.forEach((link) => link.removeEventListener("click", onLinkClick)));
    }

    // Reveal sections + counter
    if (revealSections.length > 0) {
      if ("IntersectionObserver" in window) {
        sectionObserver = new IntersectionObserver(
          (entries, observer) => {
            entries.forEach((entry) => {
              if (!entry.isIntersecting) {
                return;
              }

              const target = entry.target as HTMLElement;
              target.classList.add("is-visible");
              if (target.classList.contains("specialists-section")) {
                startCounterAnimation(target);
              }
              observer.unobserve(target);
            });
          },
          {
            threshold: 0.2,
            rootMargin: "0px 0px -40px 0px",
          }
        );

        revealSections.forEach((section) => sectionObserver?.observe(section));
        cleanupFns.push(() => sectionObserver?.disconnect());
      } else {
        revealSections.forEach((section) => {
          section.classList.add("is-visible");
          if (section.classList.contains("specialists-section")) {
            startCounterAnimation(section);
          }
        });
      }
    }

    // --- Public Google Calendar (ICS) -> disable busy dates in Flatpickr ---
    type BusyRange = { startMin: number; endMin: number };

    const WORK_START_MIN = 8 * 60;
    const WORK_END_MIN = 20 * 60;

    const busyRangesByDate = new Map<string, BusyRange[]>();
    let selectedServiceDateYmd: string | null = null;

    function clampRange(range: BusyRange) {
      const startMin = Math.max(0, Math.min(24 * 60, range.startMin));
      const endMin = Math.max(0, Math.min(24 * 60, range.endMin));
      if (endMin <= startMin) return null;
      return { startMin, endMin };
    }

    function addBusyRangeForDate(ymd: string, range: BusyRange) {
      const normalized = clampRange(range);
      if (!normalized) return;
      const list = busyRangesByDate.get(ymd) ?? [];
      list.push(normalized);
      busyRangesByDate.set(ymd, list);
    }

    function mergedRangesForDate(ymd: string) {
      const ranges = (busyRangesByDate.get(ymd) ?? [])
        .map(clampRange)
        .filter((r): r is BusyRange => Boolean(r))
        .sort((a, b) => a.startMin - b.startMin || a.endMin - b.endMin);

      const merged: BusyRange[] = [];
      for (const r of ranges) {
        const last = merged[merged.length - 1];
        if (!last || r.startMin > last.endMin) {
          merged.push({ ...r });
        } else {
          last.endMin = Math.max(last.endMin, r.endMin);
        }
      }
      return merged;
    }

    function isWorkdayFullyBusy(ymd: string) {
      const merged = mergedRangesForDate(ymd);
      let cursor = WORK_START_MIN;
      for (const r of merged) {
        const start = Math.max(r.startMin, WORK_START_MIN);
        const end = Math.min(r.endMin, WORK_END_MIN);
        if (end <= WORK_START_MIN || start >= WORK_END_MIN) {
          continue;
        }
        if (start > cursor) {
          return false;
        }
        cursor = Math.max(cursor, end);
        if (cursor >= WORK_END_MIN) {
          return true;
        }
      }
      return cursor >= WORK_END_MIN;
    }

    function minutesInTimeZone(date: Date, timeZone: string) {
      const fmt = new Intl.DateTimeFormat("en-GB", {
        timeZone,
        hour: "2-digit",
        minute: "2-digit",
        hourCycle: "h23",
      });
      const parts = fmt.formatToParts(date);
      const hh = Number.parseInt(parts.find((p) => p.type === "hour")?.value || "0", 10);
      const mm = Number.parseInt(parts.find((p) => p.type === "minute")?.value || "0", 10);
      return hh * 60 + mm;
    }

    function initBusyDatePicker(): FlatpickrInstance | null {
      const dateInput =
        document.querySelector<HTMLInputElement>(".js-service-date") ||
        document.querySelector<HTMLInputElement>('input[name="serviceDate"]');

      if (!dateInput || typeof window.flatpickr !== "function") {
        return null;
      }

      const GOOGLE_ICS_URL =
        dateInput.dataset.icsUrl ||
        "https://calendar.google.com/calendar/ical/ef33cd75da97d7be2c22fe2f7d389cf158c9ad94436a6fc4a4ed59a375ff8a1e%40group.calendar.google.com/public/basic.ics";
      const TIME_ZONE = "Asia/Kathmandu";

      const ymdFormatter = new Intl.DateTimeFormat("en-CA", {
        timeZone: TIME_ZONE,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      });

      function ymdInTimeZone(date: Date) {
        return ymdFormatter.format(date);
      }

      function nextYmd(ymd: string) {
        const [y, m, d] = ymd.split("-").map((n) => Number.parseInt(n, 10));
        if (!y || !m || !d) return null;
        const dt = new Date(Date.UTC(y, m - 1, d));
        dt.setUTCDate(dt.getUTCDate() + 1);
        return dt.toISOString().slice(0, 10);
      }

      function pad2(n: number) {
        return String(n).padStart(2, "0");
      }

      function ymdFromIcalDate(icalTime: any) {
        const year = Number(icalTime?.year);
        const month = Number(icalTime?.month);
        const day = Number(icalTime?.day);
        if (!Number.isFinite(year) || !Number.isFinite(month) || !Number.isFinite(day)) {
          return null;
        }
        if (year < 1 || month < 1 || month > 12 || day < 1 || day > 31) {
          return null;
        }
        return `${year}-${pad2(month)}-${pad2(day)}`;
      }

      function addAllDayBusy(startYmd: string, endYmdExclusive: string) {
        let cursor: string | null = startYmd;
        while (cursor && cursor < endYmdExclusive) {
          addBusyRangeForDate(cursor, { startMin: 0, endMin: 24 * 60 });
          cursor = nextYmd(cursor);
        }
      }

      function addTimedBusy(startJs: Date, endJs: Date) {
        if (!(startJs instanceof Date) || Number.isNaN(startJs.getTime())) return;
        if (!(endJs instanceof Date) || Number.isNaN(endJs.getTime()) || endJs <= startJs) {
          const startYmd = ymdInTimeZone(startJs);
          const startMin = minutesInTimeZone(startJs, TIME_ZONE);
          addBusyRangeForDate(startYmd, { startMin, endMin: Math.min(24 * 60, startMin + 60) });
          return;
        }

        const startYmd = ymdInTimeZone(startJs);
        const endYmd = ymdInTimeZone(endJs);
        const startMin = minutesInTimeZone(startJs, TIME_ZONE);
        const endMin = minutesInTimeZone(endJs, TIME_ZONE);

        if (startYmd === endYmd) {
          addBusyRangeForDate(startYmd, { startMin, endMin });
          return;
        }

        addBusyRangeForDate(startYmd, { startMin, endMin: 24 * 60 });

        let cursor = nextYmd(startYmd);
        while (cursor && cursor < endYmd) {
          addBusyRangeForDate(cursor, { startMin: 0, endMin: 24 * 60 });
          cursor = nextYmd(cursor);
        }

        addBusyRangeForDate(endYmd, { startMin: 0, endMin });
      }

      async function fetchIcsText(url: string) {
        const cacheBustedUrl = `${url}${url.includes("?") ? "&" : "?"}_=${Date.now()}`;
        const proxies: Array<null | ((u: string) => string)> = [
          null,
          (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
        ];

        let lastError: unknown;
        for (const proxy of proxies) {
          const targetUrl = proxy ? proxy(cacheBustedUrl) : cacheBustedUrl;
          try {
            const res = await fetch(targetUrl, {
              method: "GET",
              cache: "no-store",
            });
            if (!res.ok) {
              throw new Error(`HTTP ${res.status}`);
            }
            return await res.text();
          } catch (err) {
            lastError = err;
          }
        }

        throw lastError || new Error("Failed to fetch ICS");
      }

      function extractBusyFromIcs(icsText: string, { rangeDays = 730 } = {}) {
        if (!window.ICAL) {
          throw new Error("ICAL is not available (ical.js failed to load)");
        }

        const jcalData = window.ICAL.parse(icsText);
        const vcalendar = new window.ICAL.Component(jcalData);
        const vevents = vcalendar.getAllSubcomponents("vevent");

        const rangeEndJs = new Date(Date.now() + rangeDays * 24 * 60 * 60 * 1000);

        for (const vevent of vevents) {
          const event = new window.ICAL.Event(vevent);

          if (event.isRecurring()) {
            const rangeStart = window.ICAL.Time.fromJSDate(new Date(), true);
            const iterator = event.iterator(rangeStart);

            while (true) {
              const next = iterator.next();
              if (!next) {
                break;
              }

              const startJs = next.toJSDate();
              if (startJs > rangeEndJs) {
                break;
              }

              const details = event.getOccurrenceDetails(next);
              const occStartTime = details.startDate || next;
              const occEndTime = details.endDate || details.startDate;
              const occStartJs = occStartTime?.toJSDate?.() || startJs;
              const occEndJs = occEndTime?.toJSDate?.() || new Date(occStartJs.getTime());

              if (occStartTime?.isDate) {
                const startYmd = ymdFromIcalDate(occStartTime);
                const endYmdExclusive = ymdFromIcalDate(occEndTime) || (startYmd ? nextYmd(startYmd) : null);
                if (startYmd && endYmdExclusive) {
                  addAllDayBusy(startYmd, endYmdExclusive);
                }
              } else {
                addTimedBusy(occStartJs, occEndJs);
              }
            }
          } else {
            const startTime = event.startDate;
            const endTime = event.endDate;
            const startJs = startTime?.toJSDate?.();
            const endJs = endTime?.toJSDate?.();

            if (startTime?.isDate && startJs && endJs) {
              const startYmd = ymdFromIcalDate(startTime);
              const endYmdExclusive = ymdFromIcalDate(endTime) || (startYmd ? nextYmd(startYmd) : null);
              if (startYmd && endYmdExclusive) {
                addAllDayBusy(startYmd, endYmdExclusive);
              }
            } else if (startJs) {
              addTimedBusy(startJs, endJs || new Date(startJs.getTime()));
            }
          }
        }
      }

      const picker = window.flatpickr(dateInput, {
        dateFormat: "d/m/Y",
        disableMobile: true,
        disable: [
          (date: Date) => {
            const ymd = ymdInTimeZone(date);
            return isWorkdayFullyBusy(ymd);
          },
        ],
        onDayCreate: (_dObj: unknown, _dStr: string, _fp: unknown, dayElem: HTMLElement) => {
          const dateObj = (dayElem as any)?.dateObj as Date | undefined;
          if (!(dateObj instanceof Date) || Number.isNaN(dateObj.getTime())) {
            return;
          }

          const ymd = ymdInTimeZone(dateObj);
          if (isWorkdayFullyBusy(ymd)) {
            dayElem.classList.add("is-busy-day");
            dayElem.setAttribute("aria-label", `${ymd} (Busy)`);
          }
        },
        onChange: (selectedDates: Date[]) => {
          const d = selectedDates?.[0];
          selectedServiceDateYmd = d ? ymdInTimeZone(d) : null;
          timePicker?.redraw();
        },
      });

      async function fetchBookedDatesFromDb() {
        try {
          const res = await fetch("/api/bookings", {
            method: "GET",
            cache: "no-store",
          });

          if (!res.ok) {
            throw new Error(`HTTP ${res.status}`);
          }

          const data = (await res.json()) as any;
          const bookings =
            data && typeof data === "object" && Array.isArray(data.bookings)
              ? (data.bookings as unknown[])
              : [];

          let count = 0;
          for (const b of bookings) {
            const ymd = (b as any)?.serviceDateYmd;
            const startMin = (b as any)?.startMin;
            const endMin = (b as any)?.endMin;
            if (
              typeof ymd === "string" &&
              /^\d{4}-\d{2}-\d{2}$/.test(ymd) &&
              typeof startMin === "number" &&
              typeof endMin === "number"
            ) {
              addBusyRangeForDate(ymd, { startMin, endMin });
              count += 1;
            }
          }

          // eslint-disable-next-line no-console
          console.info(`DB bookings loaded: ${count}`);
        } catch (err) {
          // eslint-disable-next-line no-console
          console.warn("Could not load busy dates from DB:", err);
        }
      }

      (async () => {
        await Promise.allSettled([
          (async () => {
            try {
              const icsText = await fetchIcsText(GOOGLE_ICS_URL);
              extractBusyFromIcs(icsText);

              // eslint-disable-next-line no-console
              console.info("Calendar busy times loaded.");

              if (busyRangesByDate.size === 0) {
                // eslint-disable-next-line no-console
                console.warn(
                  "Calendar loaded but no busy dates were found. Check the calendar feed and event visibility."
                );
              }
            } catch (err) {
              // If calendar fetch/parse fails, keep the picker usable.
              // eslint-disable-next-line no-console
              console.warn("Could not load busy dates from calendar:", err);
            }
          })(),
          fetchBookedDatesFromDb(),
        ]);

        picker.redraw();
      })();

      return picker;
    }

    // --- Time picker (Flatpickr) ---
    function initServiceTimePicker(): FlatpickrInstance | null {
      const timeInput =
        document.querySelector<HTMLInputElement>(".js-service-time") ||
        document.querySelector<HTMLInputElement>('input[name="serviceTime"]');

      if (!timeInput || typeof window.flatpickr !== "function") {
        return null;
      }

      const picker = window.flatpickr(timeInput, {
        enableTime: true,
        noCalendar: true,
        time_24hr: true,
        dateFormat: "H:i",
        minuteIncrement: 30,
        minTime: "08:00",
        maxTime: "20:00",
        disableMobile: true,
        disable: [
          (date: Date) => {
            if (!selectedServiceDateYmd) {
              return false;
            }

            // flatpickr time-only uses a Date; interpret its local HH:mm.
            const timeMin = date.getHours() * 60 + date.getMinutes();

            const ranges = mergedRangesForDate(selectedServiceDateYmd);
            for (const r of ranges) {
              if (timeMin >= r.startMin && timeMin < r.endMin) {
                return true;
              }
            }
            return false;
          },
        ],
      });

      return picker;
    }

    // --- Frontend-only form submit (no backend) ---
    function wireEstimateFormSubmit() {
      const form = document.querySelector<HTMLFormElement>(".estimate-form");
      if (!form) {
        return () => {};
      }

      function buildGoogleCalendarTemplateUrl(formData: FormData) {
        const serviceDate = String(formData.get("serviceDate") || "").trim();
        // Flatpickr dateFormat is d/m/Y (e.g. 03/05/2026)
        const parts = serviceDate.split("/").map((p) => p.trim());
        if (parts.length !== 3) {
          return null;
        }
        const [dd, mm, yyyy] = parts;
        if (!dd || !mm || !yyyy) {
          return null;
        }

        const yyyymmdd = `${yyyy}${mm.padStart(2, "0")}${dd.padStart(2, "0")}`;

        const titleBits = [String(formData.get("serviceType") || "").trim(), "Cleaning"];
        const fullName = String(formData.get("fullName") || "").trim();
        if (fullName) {
          titleBits.push("-", fullName);
        }
        const text = titleBits.filter(Boolean).join(" ");

        const detailsLines: string[] = [];
        const fields: Array<[string, string]> = [
          ["Name", "fullName"],
          ["Phone", "phone"],
          ["Email", "email"],
          ["Service type", "serviceType"],
          ["Frequency", "frequency"],
          ["Rooms", "rooms"],
          ["Bedrooms", "bedrooms"],
          ["Bathrooms", "bathrooms"],
          ["Property type", "propertyType"],
          ["Approx SF", "approxSf"],
          ["ZIP", "zipCode"],
          ["Time", "serviceTime"],
          ["Address", "address"],
        ];

        for (const [label, key] of fields) {
          const value = String(formData.get(key) || "").trim();
          if (value) {
            detailsLines.push(`${label}: ${value}`);
          }
        }

        const url = new URL("https://calendar.google.com/calendar/render");
        url.searchParams.set("action", "TEMPLATE");
        url.searchParams.set("text", text || "Cleaning booking");
        // All-day event on the selected date.
        // Google expects end date to be exclusive, so use +1 day.
        const endDate = new Date(Number(yyyy), Number(mm) - 1, Number(dd));
        if (!Number.isNaN(endDate.getTime())) {
          endDate.setDate(endDate.getDate() + 1);
          const endY = String(endDate.getFullYear());
          const endM = String(endDate.getMonth() + 1).padStart(2, "0");
          const endD = String(endDate.getDate()).padStart(2, "0");
          url.searchParams.set("dates", `${yyyymmdd}/${endY}${endM}${endD}`);
        } else {
          url.searchParams.set("dates", `${yyyymmdd}/${yyyymmdd}`);
        }
        url.searchParams.set("ctz", "Asia/Kathmandu");
        if (detailsLines.length) {
          url.searchParams.set("details", detailsLines.join("\n"));
        }
        return url.toString();
      }

      const onSubmit = (event: Event) => {
        // Use Formspree (or any external handler) via AJAX to avoid page navigation.
        event.preventDefault();

        const endpoint = form.getAttribute("action");
        if (!endpoint) {
          // eslint-disable-next-line no-console
          console.warn("Form submission skipped: missing form action URL.");
          return;
        }

        const submitBtn = form.querySelector<HTMLButtonElement>(
          'button[type="submit"]'
        );
        const originalBtnHtml = submitBtn ? submitBtn.innerHTML : "";

        const outgoingData = new FormData(form);
        const calendarUrl = buildGoogleCalendarTemplateUrl(outgoingData);
        // Open a blank window immediately (user gesture) to avoid popup blockers.
        // We’ll navigate it after the async submit succeeds.
        const calendarWindow = calendarUrl ? window.open("", "_blank") : null;
        if (calendarWindow && calendarWindow.document) {
          calendarWindow.document.title = "Creating calendar event…";
          calendarWindow.document.body.innerText = "Preparing calendar event…";
        }

        const ensureStatusEl = () => {
          let el = form.querySelector<HTMLParagraphElement>(".js-form-status");
          if (!el) {
            el = document.createElement("p");
            el.className = "js-form-status";
            el.setAttribute("aria-live", "polite");
            el.style.margin = "0.85rem 0 0";
            el.style.fontSize = "0.95rem";
            form.appendChild(el);
          }
          return el;
        };

        const statusEl = ensureStatusEl();
        statusEl.textContent = "Sending...";

        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerText = "Sending...";
        }

        (async () => {
          try {
            const res = await fetch(endpoint, {
              method: "POST",
              body: outgoingData,
              headers: {
                Accept: "application/json",
              },
            });

            if (res.ok) {
              statusEl.textContent = "Thanks! Your booking was saved.";

              try {
                const data = (await res.json()) as any;
                if (
                  data &&
                  typeof data.serviceDateYmd === "string" &&
                  typeof data.startMin === "number" &&
                  typeof data.endMin === "number"
                ) {
                  addBusyRangeForDate(data.serviceDateYmd, {
                    startMin: data.startMin,
                    endMin: data.endMin,
                  });
                  busyPicker?.redraw();
                  timePicker?.redraw();
                }
              } catch {
                // ignore JSON parse errors
              }

              if (calendarUrl) {
                if (calendarWindow && !calendarWindow.closed) {
                  calendarWindow.location.href = calendarUrl;
                } else {
                  // Popup blocked; provide a clickable link.
                  statusEl.textContent = "";
                  statusEl.append("Thanks! Your booking was saved. ");
                  const link = document.createElement("a");
                  link.href = calendarUrl;
                  link.target = "_blank";
                  link.rel = "noopener noreferrer";
                  link.textContent = "Add to Google Calendar";
                  statusEl.append(link);
                  statusEl.append(".");
                }
              }
              form.reset();
              return;
            }

            if (calendarWindow && !calendarWindow.closed) {
              calendarWindow.close();
            }

            let message = `Could not save booking (HTTP ${res.status}).`;
            try {
              const data = await res.json();
              if (data && typeof data.error === "string") {
                message = data.error;
              }
            } catch {
              // ignore JSON parse errors
            }

            statusEl.textContent = message;
          } catch (err) {
            // eslint-disable-next-line no-console
            console.warn("Form submission failed:", err);
            statusEl.textContent = "Network error. Please try again.";

            if (calendarWindow && !calendarWindow.closed) {
              calendarWindow.close();
            }
          } finally {
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = originalBtnHtml;
            }
          }
        })();
      };

      form.addEventListener("submit", onSubmit);
      return () => form.removeEventListener("submit", onSubmit);
    }

    // Flatpickr + ICAL might load after this effect.
    // We try now, and also retry for a short time in case the scripts load late.
    let busyPicker: FlatpickrInstance | null = null;
    let timePicker: FlatpickrInstance | null = null;

    const tryInitPickers = () => {
      if (!busyPicker) busyPicker = initBusyDatePicker();
      if (!timePicker) timePicker = initServiceTimePicker();
    };

    tryInitPickers();

    let initAttempts = 0;
    const initTimer = window.setInterval(() => {
      initAttempts += 1;
      tryInitPickers();

      const allReady = Boolean(busyPicker) && Boolean(timePicker);
      if (allReady || initAttempts >= 50) {
        window.clearInterval(initTimer);
      }
    }, 200);
    cleanupFns.push(() => window.clearInterval(initTimer));

    const unbindForm = wireEstimateFormSubmit();
    cleanupFns.push(unbindForm);

    cleanupFns.push(() => busyPicker?.destroy());
    cleanupFns.push(() => timePicker?.destroy());

    return () => {
      cleanupFns.forEach((fn) => fn());
    };
  }, []);

  return null;
}
